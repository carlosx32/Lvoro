package presentacion;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import logica.HojaVida;
import persistencia.BaseDatos;
import presentacion.FormHojaDeVida.*;

;

//esta clase permite iniciar la aplicacion y los formularios
//ademas esresponsale de guardar los objetos(posteriormente se puede aplicar algun patron para esto)
public class Gestor {

    private IngresoHoja ventanaHVS;
    private BaseDatos basedatos;
    HojaVida hv;

    public BaseDatos getBasedatos() {
        return basedatos;
    }

    public void setBasedatos(BaseDatos basedatos) {
        this.basedatos = basedatos;
    }

    public void iniciar() {	//este metodo 
        int form2open = Integer.parseInt(JOptionPane.showInputDialog("Selecione\n1. HV"));
        if (form2open == 1) {
            this.getVentanaHojaVida();
        } else {
            this.getVentanaHojaVida();
        }
    }

    public JFrame getVentanaHojaVida() {
        if (ventanaHVS == null) {
            ventanaHVS = new IngresoHoja(this);
        }
        return ventanaHVS;
    }

    public boolean guarda() {
        if (this.getBasedatos().guardar(hv)) {
            return true;
        }
        return false;
    }
}
