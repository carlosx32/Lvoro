package presentacion.FormHojaDeVida;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
//este controlador aun no eta implementado

public class Controlador implements ActionListener {

    private IngresoHoja ventana;

    public Controlador(IngresoHoja aThis) {
        ventana = aThis;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        if ((((JButton) e.getSource()).getText() == "Guardar")) {
            ventana.getModelo().guarda();
        }
//		segun el nombre del boton llama al modelo para ejecutar una opcion
//		else if ((((JButton) e.getSource()).getText()=="Pausar")) {
//			ventana.getModelo().pausarHilo();
//			((JButton) e.getSource()).setText("Reanudar");
//		}else if ((((JButton) e.getSource()).getText()=="Reanudar")) {
//			ventana.getModelo().reanudadHilo();
//			((JButton) e.getSource()).setText("Pausar");
//		}
    }

}
