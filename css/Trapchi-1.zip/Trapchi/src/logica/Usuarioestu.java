/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

/**
 *
 * @author usuario
 */
public class Usuarioestu {
    String Nmprimaria;
    String Nmsecundaria;
    String Nmpregrado;
    String Nmpostgrado;
    String fechapri;
    String fechasec;
    String fechapre;
    String fechapost;

    public String getNmprimaria() {
        return Nmprimaria;
    }

    public void setNmprimaria(String Nmprimaria) {
        this.Nmprimaria = Nmprimaria;
    }

    public String getNmsecundaria() {
        return Nmsecundaria;
    }

    public void setNmsecundaria(String Nmsecundaria) {
        this.Nmsecundaria = Nmsecundaria;
    }

    public String getNmpregrado() {
        return Nmpregrado;
    }

    public void setNmpregrado(String Nmpregrado) {
        this.Nmpregrado = Nmpregrado;
    }

    public String getNmpostgrado() {
        return Nmpostgrado;
    }

    public void setNmpostgrado(String Nmpostgrado) {
        this.Nmpostgrado = Nmpostgrado;
    }

    public String getFechapri() {
        return fechapri;
    }

    public void setFechapri(String fechapri) {
        this.fechapri = fechapri;
    }

    public String getFechasec() {
        return fechasec;
    }

    public void setFechasec(String fechasec) {
        this.fechasec = fechasec;
    }

    public String getFechapre() {
        return fechapre;
    }

    public void setFechapre(String fechapre) {
        this.fechapre = fechapre;
    }

    public String getFechapost() {
        return fechapost;
    }

    public void setFechapost(String fechapost) {
        this.fechapost = fechapost;
    }

    public int getIdiomas() {
        return idiomas;
    }

    public void setIdiomas(int idiomas) {
        this.idiomas = idiomas;
    }
    int idiomas;
    
}
