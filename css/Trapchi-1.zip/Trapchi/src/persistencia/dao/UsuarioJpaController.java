/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia.dao;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import persistencia.vo.Calificacion;
import persistencia.vo.ExperienciaLaboral;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import persistencia.dao.exceptions.IllegalOrphanException;
import persistencia.dao.exceptions.NonexistentEntityException;
import persistencia.dao.exceptions.PreexistingEntityException;
import persistencia.vo.Usuario1;

/**
 *
 * @author USER
 */
public class UsuarioJpaController implements Serializable {

    public UsuarioJpaController() {
        this.emf = Persistence.createEntityManagerFactory("TrapchiPU");
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Usuario1 usuario) throws IllegalOrphanException, PreexistingEntityException, Exception {
        List<String> illegalOrphanMessages = null;
        Calificacion calificacionCedulaOrphanCheck = usuario.getCalificacionCedula();
        if (calificacionCedulaOrphanCheck != null) {
            Usuario1 oldUsuarioCedulaOfCalificacionCedula = calificacionCedulaOrphanCheck.getUsuarioCedula();
            if (oldUsuarioCedulaOfCalificacionCedula != null) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("The Calificacion " + calificacionCedulaOrphanCheck + " already has an item of type Usuario whose calificacionCedula column cannot be null. Please make another selection for the calificacionCedula field.");
            }
        }
        if (illegalOrphanMessages != null) {
            throw new IllegalOrphanException(illegalOrphanMessages);
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Calificacion calificacion = usuario.getCalificacion();
            if (calificacion != null) {
                calificacion = em.getReference(calificacion.getClass(), calificacion.getCedula());
                usuario.setCalificacion(calificacion);
            }
            Calificacion calificacionCedula = usuario.getCalificacionCedula();
            if (calificacionCedula != null) {
                calificacionCedula = em.getReference(calificacionCedula.getClass(), calificacionCedula.getCedula());
                usuario.setCalificacionCedula(calificacionCedula);
            }
            ExperienciaLaboral experienciaLaboralCodigo = usuario.getExperienciaLaboralCodigo();
            if (experienciaLaboralCodigo != null) {
                experienciaLaboralCodigo = em.getReference(experienciaLaboralCodigo.getClass(), experienciaLaboralCodigo.getCodigo());
                usuario.setExperienciaLaboralCodigo(experienciaLaboralCodigo);
            }
            em.persist(usuario);
            if (calificacion != null) {
                Usuario1 oldUsuarioCedulaOfCalificacion = calificacion.getUsuarioCedula();
                if (oldUsuarioCedulaOfCalificacion != null) {
                    oldUsuarioCedulaOfCalificacion.setCalificacion(null);
                    oldUsuarioCedulaOfCalificacion = em.merge(oldUsuarioCedulaOfCalificacion);
                }
                calificacion.setUsuarioCedula(usuario);
                calificacion = em.merge(calificacion);
            }
            if (calificacionCedula != null) {
                calificacionCedula.setUsuarioCedula(usuario);
                calificacionCedula = em.merge(calificacionCedula);
            }
            if (experienciaLaboralCodigo != null) {
                experienciaLaboralCodigo.getUsuarioCollection().add(usuario);
                experienciaLaboralCodigo = em.merge(experienciaLaboralCodigo);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findUsuario(usuario.getCedula()) != null) {
                throw new PreexistingEntityException("Usuario " + usuario + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Usuario1 usuario) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuario1 persistentUsuario = em.find(Usuario1.class, usuario.getCedula());
            Calificacion calificacionOld = persistentUsuario.getCalificacion();
            Calificacion calificacionNew = usuario.getCalificacion();
            Calificacion calificacionCedulaOld = persistentUsuario.getCalificacionCedula();
            Calificacion calificacionCedulaNew = usuario.getCalificacionCedula();
            ExperienciaLaboral experienciaLaboralCodigoOld = persistentUsuario.getExperienciaLaboralCodigo();
            ExperienciaLaboral experienciaLaboralCodigoNew = usuario.getExperienciaLaboralCodigo();
            List<String> illegalOrphanMessages = null;
            if (calificacionOld != null && !calificacionOld.equals(calificacionNew)) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("You must retain Calificacion " + calificacionOld + " since its usuarioCedula field is not nullable.");
            }
            if (calificacionCedulaOld != null && !calificacionCedulaOld.equals(calificacionCedulaNew)) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("You must retain Calificacion " + calificacionCedulaOld + " since its usuarioCedula field is not nullable.");
            }
            if (calificacionCedulaNew != null && !calificacionCedulaNew.equals(calificacionCedulaOld)) {
                Usuario1 oldUsuarioCedulaOfCalificacionCedula = calificacionCedulaNew.getUsuarioCedula();
                if (oldUsuarioCedulaOfCalificacionCedula != null) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("The Calificacion " + calificacionCedulaNew + " already has an item of type Usuario whose calificacionCedula column cannot be null. Please make another selection for the calificacionCedula field.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (calificacionNew != null) {
                calificacionNew = em.getReference(calificacionNew.getClass(), calificacionNew.getCedula());
                usuario.setCalificacion(calificacionNew);
            }
            if (calificacionCedulaNew != null) {
                calificacionCedulaNew = em.getReference(calificacionCedulaNew.getClass(), calificacionCedulaNew.getCedula());
                usuario.setCalificacionCedula(calificacionCedulaNew);
            }
            if (experienciaLaboralCodigoNew != null) {
                experienciaLaboralCodigoNew = em.getReference(experienciaLaboralCodigoNew.getClass(), experienciaLaboralCodigoNew.getCodigo());
                usuario.setExperienciaLaboralCodigo(experienciaLaboralCodigoNew);
            }
            usuario = em.merge(usuario);
            if (calificacionNew != null && !calificacionNew.equals(calificacionOld)) {
                Usuario1 oldUsuarioCedulaOfCalificacion = calificacionNew.getUsuarioCedula();
                if (oldUsuarioCedulaOfCalificacion != null) {
                    oldUsuarioCedulaOfCalificacion.setCalificacion(null);
                    oldUsuarioCedulaOfCalificacion = em.merge(oldUsuarioCedulaOfCalificacion);
                }
                calificacionNew.setUsuarioCedula(usuario);
                calificacionNew = em.merge(calificacionNew);
            }
            if (calificacionCedulaNew != null && !calificacionCedulaNew.equals(calificacionCedulaOld)) {
                calificacionCedulaNew.setUsuarioCedula(usuario);
                calificacionCedulaNew = em.merge(calificacionCedulaNew);
            }
            if (experienciaLaboralCodigoOld != null && !experienciaLaboralCodigoOld.equals(experienciaLaboralCodigoNew)) {
                experienciaLaboralCodigoOld.getUsuarioCollection().remove(usuario);
                experienciaLaboralCodigoOld = em.merge(experienciaLaboralCodigoOld);
            }
            if (experienciaLaboralCodigoNew != null && !experienciaLaboralCodigoNew.equals(experienciaLaboralCodigoOld)) {
                experienciaLaboralCodigoNew.getUsuarioCollection().add(usuario);
                experienciaLaboralCodigoNew = em.merge(experienciaLaboralCodigoNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                BigDecimal id = usuario.getCedula();
                if (findUsuario(id) == null) {
                    throw new NonexistentEntityException("The usuario with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(BigDecimal id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuario1 usuario;
            try {
                usuario = em.getReference(Usuario1.class, id);
                usuario.getCedula();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The usuario with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Calificacion calificacionOrphanCheck = usuario.getCalificacion();
            if (calificacionOrphanCheck != null) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Usuario (" + usuario + ") cannot be destroyed since the Calificacion " + calificacionOrphanCheck + " in its calificacion field has a non-nullable usuarioCedula field.");
            }
            Calificacion calificacionCedulaOrphanCheck = usuario.getCalificacionCedula();
            if (calificacionCedulaOrphanCheck != null) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Usuario (" + usuario + ") cannot be destroyed since the Calificacion " + calificacionCedulaOrphanCheck + " in its calificacionCedula field has a non-nullable usuarioCedula field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            ExperienciaLaboral experienciaLaboralCodigo = usuario.getExperienciaLaboralCodigo();
            if (experienciaLaboralCodigo != null) {
                experienciaLaboralCodigo.getUsuarioCollection().remove(usuario);
                experienciaLaboralCodigo = em.merge(experienciaLaboralCodigo);
            }
            em.remove(usuario);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Usuario1> findUsuarioEntities() {
        return findUsuarioEntities(true, -1, -1);
    }

    public List<Usuario1> findUsuarioEntities(int maxResults, int firstResult) {
        return findUsuarioEntities(false, maxResults, firstResult);
    }

    private List<Usuario1> findUsuarioEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Usuario1.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Usuario1 findUsuario(BigDecimal id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Usuario1.class, id);
        } finally {
            em.close();
        }
    }

    public int getUsuarioCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Usuario1> rt = cq.from(Usuario1.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
