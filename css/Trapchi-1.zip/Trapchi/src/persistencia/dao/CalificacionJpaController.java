/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia.dao;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import persistencia.vo.Usuario1;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import persistencia.dao.exceptions.IllegalOrphanException;
import persistencia.dao.exceptions.NonexistentEntityException;
import persistencia.dao.exceptions.PreexistingEntityException;
import persistencia.vo.Calificacion;

/**
 *
 * @author USER
 */
public class CalificacionJpaController implements Serializable {

    public CalificacionJpaController() {
        this.emf = Persistence.createEntityManagerFactory("TrapchiPU");
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Calificacion calificacion) throws IllegalOrphanException, PreexistingEntityException, Exception {
        List<String> illegalOrphanMessages = null;
        Usuario1 usuarioCedulaOrphanCheck = calificacion.getUsuarioCedula();
        if (usuarioCedulaOrphanCheck != null) {
            Calificacion oldCalificacionOfUsuarioCedula = usuarioCedulaOrphanCheck.getCalificacion();
            if (oldCalificacionOfUsuarioCedula != null) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("The Usuario " + usuarioCedulaOrphanCheck + " already has an item of type Calificacion whose usuarioCedula column cannot be null. Please make another selection for the usuarioCedula field.");
            }
        }
        if (illegalOrphanMessages != null) {
            throw new IllegalOrphanException(illegalOrphanMessages);
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuario1 usuarioCedula = calificacion.getUsuarioCedula();
            if (usuarioCedula != null) {
                usuarioCedula = em.getReference(usuarioCedula.getClass(), usuarioCedula.getCedula());
                calificacion.setUsuarioCedula(usuarioCedula);
            }
            Usuario1 usuario = calificacion.getUsuario();
            if (usuario != null) {
                usuario = em.getReference(usuario.getClass(), usuario.getCedula());
                calificacion.setUsuario(usuario);
            }
            em.persist(calificacion);
            if (usuarioCedula != null) {
                usuarioCedula.setCalificacion(calificacion);
                usuarioCedula = em.merge(usuarioCedula);
            }
            if (usuario != null) {
                Calificacion oldCalificacionCedulaOfUsuario = usuario.getCalificacionCedula();
                if (oldCalificacionCedulaOfUsuario != null) {
                    oldCalificacionCedulaOfUsuario.setUsuario(null);
                    oldCalificacionCedulaOfUsuario = em.merge(oldCalificacionCedulaOfUsuario);
                }
                usuario.setCalificacionCedula(calificacion);
                usuario = em.merge(usuario);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findCalificacion(calificacion.getCedula()) != null) {
                throw new PreexistingEntityException("Calificacion " + calificacion + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Calificacion calificacion) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Calificacion persistentCalificacion = em.find(Calificacion.class, calificacion.getCedula());
            Usuario1 usuarioCedulaOld = persistentCalificacion.getUsuarioCedula();
            Usuario1 usuarioCedulaNew = calificacion.getUsuarioCedula();
            Usuario1 usuarioOld = persistentCalificacion.getUsuario();
            Usuario1 usuarioNew = calificacion.getUsuario();
            List<String> illegalOrphanMessages = null;
            if (usuarioCedulaNew != null && !usuarioCedulaNew.equals(usuarioCedulaOld)) {
                Calificacion oldCalificacionOfUsuarioCedula = usuarioCedulaNew.getCalificacion();
                if (oldCalificacionOfUsuarioCedula != null) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("The Usuario " + usuarioCedulaNew + " already has an item of type Calificacion whose usuarioCedula column cannot be null. Please make another selection for the usuarioCedula field.");
                }
            }
            if (usuarioOld != null && !usuarioOld.equals(usuarioNew)) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("You must retain Usuario " + usuarioOld + " since its calificacionCedula field is not nullable.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (usuarioCedulaNew != null) {
                usuarioCedulaNew = em.getReference(usuarioCedulaNew.getClass(), usuarioCedulaNew.getCedula());
                calificacion.setUsuarioCedula(usuarioCedulaNew);
            }
            if (usuarioNew != null) {
                usuarioNew = em.getReference(usuarioNew.getClass(), usuarioNew.getCedula());
                calificacion.setUsuario(usuarioNew);
            }
            calificacion = em.merge(calificacion);
            if (usuarioCedulaOld != null && !usuarioCedulaOld.equals(usuarioCedulaNew)) {
                usuarioCedulaOld.setCalificacion(null);
                usuarioCedulaOld = em.merge(usuarioCedulaOld);
            }
            if (usuarioCedulaNew != null && !usuarioCedulaNew.equals(usuarioCedulaOld)) {
                usuarioCedulaNew.setCalificacion(calificacion);
                usuarioCedulaNew = em.merge(usuarioCedulaNew);
            }
            if (usuarioNew != null && !usuarioNew.equals(usuarioOld)) {
                Calificacion oldCalificacionCedulaOfUsuario = usuarioNew.getCalificacionCedula();
                if (oldCalificacionCedulaOfUsuario != null) {
                    oldCalificacionCedulaOfUsuario.setUsuario(null);
                    oldCalificacionCedulaOfUsuario = em.merge(oldCalificacionCedulaOfUsuario);
                }
                usuarioNew.setCalificacionCedula(calificacion);
                usuarioNew = em.merge(usuarioNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                BigDecimal id = calificacion.getCedula();
                if (findCalificacion(id) == null) {
                    throw new NonexistentEntityException("The calificacion with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(BigDecimal id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Calificacion calificacion;
            try {
                calificacion = em.getReference(Calificacion.class, id);
                calificacion.getCedula();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The calificacion with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Usuario1 usuarioOrphanCheck = calificacion.getUsuario();
            if (usuarioOrphanCheck != null) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Calificacion (" + calificacion + ") cannot be destroyed since the Usuario " + usuarioOrphanCheck + " in its usuario field has a non-nullable calificacionCedula field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Usuario1 usuarioCedula = calificacion.getUsuarioCedula();
            if (usuarioCedula != null) {
                usuarioCedula.setCalificacion(null);
                usuarioCedula = em.merge(usuarioCedula);
            }
            em.remove(calificacion);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Calificacion> findCalificacionEntities() {
        return findCalificacionEntities(true, -1, -1);
    }

    public List<Calificacion> findCalificacionEntities(int maxResults, int firstResult) {
        return findCalificacionEntities(false, maxResults, firstResult);
    }

    private List<Calificacion> findCalificacionEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Calificacion.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Calificacion findCalificacion(BigDecimal id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Calificacion.class, id);
        } finally {
            em.close();
        }
    }

    public int getCalificacionCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Calificacion> rt = cq.from(Calificacion.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
