/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia.dao;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import persistencia.vo.Usuario1;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import persistencia.dao.exceptions.NonexistentEntityException;
import persistencia.dao.exceptions.PreexistingEntityException;
import persistencia.vo.ExperienciaLaboral;

/**
 *
 * @author USER
 */
public class ExperienciaLaboralJpaController implements Serializable {

    public ExperienciaLaboralJpaController() {
        this.emf = Persistence.createEntityManagerFactory("TrapchiPU");
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(ExperienciaLaboral experienciaLaboral) throws PreexistingEntityException, Exception {
        if (experienciaLaboral.getUsuarioCollection() == null) {
            experienciaLaboral.setUsuarioCollection(new ArrayList<Usuario1>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Usuario1> attachedUsuarioCollection = new ArrayList<Usuario1>();
            for (Usuario1 usuarioCollectionUsuarioToAttach : experienciaLaboral.getUsuarioCollection()) {
                usuarioCollectionUsuarioToAttach = em.getReference(usuarioCollectionUsuarioToAttach.getClass(), usuarioCollectionUsuarioToAttach.getCedula());
                attachedUsuarioCollection.add(usuarioCollectionUsuarioToAttach);
            }
            experienciaLaboral.setUsuarioCollection(attachedUsuarioCollection);
            em.persist(experienciaLaboral);
            for (Usuario1 usuarioCollectionUsuario : experienciaLaboral.getUsuarioCollection()) {
                ExperienciaLaboral oldExperienciaLaboralCodigoOfUsuarioCollectionUsuario = usuarioCollectionUsuario.getExperienciaLaboralCodigo();
                usuarioCollectionUsuario.setExperienciaLaboralCodigo(experienciaLaboral);
                usuarioCollectionUsuario = em.merge(usuarioCollectionUsuario);
                if (oldExperienciaLaboralCodigoOfUsuarioCollectionUsuario != null) {
                    oldExperienciaLaboralCodigoOfUsuarioCollectionUsuario.getUsuarioCollection().remove(usuarioCollectionUsuario);
                    oldExperienciaLaboralCodigoOfUsuarioCollectionUsuario = em.merge(oldExperienciaLaboralCodigoOfUsuarioCollectionUsuario);
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findExperienciaLaboral(experienciaLaboral.getCodigo()) != null) {
                throw new PreexistingEntityException("ExperienciaLaboral " + experienciaLaboral + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(ExperienciaLaboral experienciaLaboral) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            ExperienciaLaboral persistentExperienciaLaboral = em.find(ExperienciaLaboral.class, experienciaLaboral.getCodigo());
            Collection<Usuario1> usuarioCollectionOld = persistentExperienciaLaboral.getUsuarioCollection();
            Collection<Usuario1> usuarioCollectionNew = experienciaLaboral.getUsuarioCollection();
            Collection<Usuario1> attachedUsuarioCollectionNew = new ArrayList<Usuario1>();
            for (Usuario1 usuarioCollectionNewUsuarioToAttach : usuarioCollectionNew) {
                usuarioCollectionNewUsuarioToAttach = em.getReference(usuarioCollectionNewUsuarioToAttach.getClass(), usuarioCollectionNewUsuarioToAttach.getCedula());
                attachedUsuarioCollectionNew.add(usuarioCollectionNewUsuarioToAttach);
            }
            usuarioCollectionNew = attachedUsuarioCollectionNew;
            experienciaLaboral.setUsuarioCollection(usuarioCollectionNew);
            experienciaLaboral = em.merge(experienciaLaboral);
            for (Usuario1 usuarioCollectionOldUsuario : usuarioCollectionOld) {
                if (!usuarioCollectionNew.contains(usuarioCollectionOldUsuario)) {
                    usuarioCollectionOldUsuario.setExperienciaLaboralCodigo(null);
                    usuarioCollectionOldUsuario = em.merge(usuarioCollectionOldUsuario);
                }
            }
            for (Usuario1 usuarioCollectionNewUsuario : usuarioCollectionNew) {
                if (!usuarioCollectionOld.contains(usuarioCollectionNewUsuario)) {
                    ExperienciaLaboral oldExperienciaLaboralCodigoOfUsuarioCollectionNewUsuario = usuarioCollectionNewUsuario.getExperienciaLaboralCodigo();
                    usuarioCollectionNewUsuario.setExperienciaLaboralCodigo(experienciaLaboral);
                    usuarioCollectionNewUsuario = em.merge(usuarioCollectionNewUsuario);
                    if (oldExperienciaLaboralCodigoOfUsuarioCollectionNewUsuario != null && !oldExperienciaLaboralCodigoOfUsuarioCollectionNewUsuario.equals(experienciaLaboral)) {
                        oldExperienciaLaboralCodigoOfUsuarioCollectionNewUsuario.getUsuarioCollection().remove(usuarioCollectionNewUsuario);
                        oldExperienciaLaboralCodigoOfUsuarioCollectionNewUsuario = em.merge(oldExperienciaLaboralCodigoOfUsuarioCollectionNewUsuario);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = experienciaLaboral.getCodigo();
                if (findExperienciaLaboral(id) == null) {
                    throw new NonexistentEntityException("The experienciaLaboral with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            ExperienciaLaboral experienciaLaboral;
            try {
                experienciaLaboral = em.getReference(ExperienciaLaboral.class, id);
                experienciaLaboral.getCodigo();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The experienciaLaboral with id " + id + " no longer exists.", enfe);
            }
            Collection<Usuario1> usuarioCollection = experienciaLaboral.getUsuarioCollection();
            for (Usuario1 usuarioCollectionUsuario : usuarioCollection) {
                usuarioCollectionUsuario.setExperienciaLaboralCodigo(null);
                usuarioCollectionUsuario = em.merge(usuarioCollectionUsuario);
            }
            em.remove(experienciaLaboral);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<ExperienciaLaboral> findExperienciaLaboralEntities() {
        return findExperienciaLaboralEntities(true, -1, -1);
    }

    public List<ExperienciaLaboral> findExperienciaLaboralEntities(int maxResults, int firstResult) {
        return findExperienciaLaboralEntities(false, maxResults, firstResult);
    }

    private List<ExperienciaLaboral> findExperienciaLaboralEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(ExperienciaLaboral.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public ExperienciaLaboral findExperienciaLaboral(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(ExperienciaLaboral.class, id);
        } finally {
            em.close();
        }
    }

    public int getExperienciaLaboralCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<ExperienciaLaboral> rt = cq.from(ExperienciaLaboral.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
