package persistencia;
/*Esta clase se encargara de la comunicacion con la base de datos, soportara la carga de conectarse y comunicarse con la base de datos 
de momento sera ineficiente para la version 1
*/

import logica.HojaVida;

public class BaseDatos {

	public boolean guardar(HojaVida hv) {
		// TODO Auto-generated method stub
		return false;
	}
		
}
