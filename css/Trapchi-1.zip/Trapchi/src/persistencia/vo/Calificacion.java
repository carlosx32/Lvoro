/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author USER
 */
@Entity
@Table(name = "calificacion")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Calificacion.findAll", query = "SELECT c FROM Calificacion c")
    , @NamedQuery(name = "Calificacion.findByEstudios", query = "SELECT c FROM Calificacion c WHERE c.estudios = :estudios")
    , @NamedQuery(name = "Calificacion.findByExperiencia", query = "SELECT c FROM Calificacion c WHERE c.experiencia = :experiencia")
    , @NamedQuery(name = "Calificacion.findByIdiomas", query = "SELECT c FROM Calificacion c WHERE c.idiomas = :idiomas")
    , @NamedQuery(name = "Calificacion.findByCertificaciones", query = "SELECT c FROM Calificacion c WHERE c.certificaciones = :certificaciones")
    , @NamedQuery(name = "Calificacion.findByActitudes", query = "SELECT c FROM Calificacion c WHERE c.actitudes = :actitudes")
    , @NamedQuery(name = "Calificacion.findByCedula", query = "SELECT c FROM Calificacion c WHERE c.cedula = :cedula")})
public class Calificacion implements Serializable {

    private static final long serialVersionUID = 1L;
    @Column(name = "estudios")
    private String estudios;
    @Column(name = "experiencia")
    private String experiencia;
    @Column(name = "idiomas")
    private String idiomas;
    @Column(name = "certificaciones")
    private String certificaciones;
    @Column(name = "actitudes")
    private String actitudes;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @Column(name = "cedula")
    private BigDecimal cedula;
    @JoinColumn(name = "usuario_cedula", referencedColumnName = "cedula")
    @OneToOne(optional = false, fetch = FetchType.EAGER)
    private Usuario1 usuarioCedula;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "calificacionCedula", fetch = FetchType.EAGER)
    private Usuario1 usuario;

    public Calificacion() {
    }

    public Calificacion(BigDecimal cedula) {
        this.cedula = cedula;
    }

    public String getEstudios() {
        return estudios;
    }

    public void setEstudios(String estudios) {
        this.estudios = estudios;
    }

    public String getExperiencia() {
        return experiencia;
    }

    public void setExperiencia(String experiencia) {
        this.experiencia = experiencia;
    }

    public String getIdiomas() {
        return idiomas;
    }

    public void setIdiomas(String idiomas) {
        this.idiomas = idiomas;
    }

    public String getCertificaciones() {
        return certificaciones;
    }

    public void setCertificaciones(String certificaciones) {
        this.certificaciones = certificaciones;
    }

    public String getActitudes() {
        return actitudes;
    }

    public void setActitudes(String actitudes) {
        this.actitudes = actitudes;
    }

    public BigDecimal getCedula() {
        return cedula;
    }

    public void setCedula(BigDecimal cedula) {
        this.cedula = cedula;
    }

    public Usuario1 getUsuarioCedula() {
        return usuarioCedula;
    }

    public void setUsuarioCedula(Usuario1 usuarioCedula) {
        this.usuarioCedula = usuarioCedula;
    }

    public Usuario1 getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario1 usuario) {
        this.usuario = usuario;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cedula != null ? cedula.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Calificacion)) {
            return false;
        }
        Calificacion other = (Calificacion) object;
        if ((this.cedula == null && other.cedula != null) || (this.cedula != null && !this.cedula.equals(other.cedula))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "persistencia.vo.Calificacion[ cedula=" + cedula + " ]";
    }
    
}
