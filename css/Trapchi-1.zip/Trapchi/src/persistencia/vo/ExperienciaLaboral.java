/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia.vo;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author USER
 */
@Entity
@Table(name = "experiencia_laboral")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ExperienciaLaboral.findAll", query = "SELECT e FROM ExperienciaLaboral e")
    , @NamedQuery(name = "ExperienciaLaboral.findByCodigo", query = "SELECT e FROM ExperienciaLaboral e WHERE e.codigo = :codigo")
    , @NamedQuery(name = "ExperienciaLaboral.findByNombreCompa\u00f1ia", query = "SELECT e FROM ExperienciaLaboral e WHERE e.nombreCompa\u00f1ia = :nombreCompa\u00f1ia")
    , @NamedQuery(name = "ExperienciaLaboral.findByCargo", query = "SELECT e FROM ExperienciaLaboral e WHERE e.cargo = :cargo")
    , @NamedQuery(name = "ExperienciaLaboral.findByFuncion", query = "SELECT e FROM ExperienciaLaboral e WHERE e.funcion = :funcion")
    , @NamedQuery(name = "ExperienciaLaboral.findByJefeInmediato", query = "SELECT e FROM ExperienciaLaboral e WHERE e.jefeInmediato = :jefeInmediato")
    , @NamedQuery(name = "ExperienciaLaboral.findByFechaInicio", query = "SELECT e FROM ExperienciaLaboral e WHERE e.fechaInicio = :fechaInicio")
    , @NamedQuery(name = "ExperienciaLaboral.findByFechaFinal", query = "SELECT e FROM ExperienciaLaboral e WHERE e.fechaFinal = :fechaFinal")
    , @NamedQuery(name = "ExperienciaLaboral.findByMotivoRetiro", query = "SELECT e FROM ExperienciaLaboral e WHERE e.motivoRetiro = :motivoRetiro")
    , @NamedQuery(name = "ExperienciaLaboral.findByAspiracionSalarial", query = "SELECT e FROM ExperienciaLaboral e WHERE e.aspiracionSalarial = :aspiracionSalarial")
    , @NamedQuery(name = "ExperienciaLaboral.findByPerfilProfesional", query = "SELECT e FROM ExperienciaLaboral e WHERE e.perfilProfesional = :perfilProfesional")})
public class ExperienciaLaboral implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "codigo")
    private Integer codigo;
    @Basic(optional = false)
    @Column(name = "nombre_compa\u00f1ia")
    private String nombreCompañia;
    @Basic(optional = false)
    @Column(name = "cargo")
    private String cargo;
    @Column(name = "funcion")
    private String funcion;
    @Column(name = "jefe_inmediato")
    private String jefeInmediato;
    @Column(name = "fecha_inicio")
    @Temporal(TemporalType.DATE)
    private Date fechaInicio;
    @Column(name = "fecha_final")
    @Temporal(TemporalType.DATE)
    private Date fechaFinal;
    @Column(name = "motivo_retiro")
    private String motivoRetiro;
    @Column(name = "aspiracion_salarial")
    private BigInteger aspiracionSalarial;
    @Column(name = "perfil_profesional")
    private String perfilProfesional;
    @OneToMany(mappedBy = "experienciaLaboralCodigo", fetch = FetchType.EAGER)
    private Collection<Usuario1> usuarioCollection;

    public ExperienciaLaboral() {
    }

    public ExperienciaLaboral(Integer codigo) {
        this.codigo = codigo;
    }

    public ExperienciaLaboral(Integer codigo, String nombreCompañia, String cargo) {
        this.codigo = codigo;
        this.nombreCompañia = nombreCompañia;
        this.cargo = cargo;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getNombreCompañia() {
        return nombreCompañia;
    }

    public void setNombreCompañia(String nombreCompañia) {
        this.nombreCompañia = nombreCompañia;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getFuncion() {
        return funcion;
    }

    public void setFuncion(String funcion) {
        this.funcion = funcion;
    }

    public String getJefeInmediato() {
        return jefeInmediato;
    }

    public void setJefeInmediato(String jefeInmediato) {
        this.jefeInmediato = jefeInmediato;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFinal() {
        return fechaFinal;
    }

    public void setFechaFinal(Date fechaFinal) {
        this.fechaFinal = fechaFinal;
    }

    public String getMotivoRetiro() {
        return motivoRetiro;
    }

    public void setMotivoRetiro(String motivoRetiro) {
        this.motivoRetiro = motivoRetiro;
    }

    public BigInteger getAspiracionSalarial() {
        return aspiracionSalarial;
    }

    public void setAspiracionSalarial(BigInteger aspiracionSalarial) {
        this.aspiracionSalarial = aspiracionSalarial;
    }

    public String getPerfilProfesional() {
        return perfilProfesional;
    }

    public void setPerfilProfesional(String perfilProfesional) {
        this.perfilProfesional = perfilProfesional;
    }

    @XmlTransient
    public Collection<Usuario1> getUsuarioCollection() {
        return usuarioCollection;
    }

    public void setUsuarioCollection(Collection<Usuario1> usuarioCollection) {
        this.usuarioCollection = usuarioCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codigo != null ? codigo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ExperienciaLaboral)) {
            return false;
        }
        ExperienciaLaboral other = (ExperienciaLaboral) object;
        if ((this.codigo == null && other.codigo != null) || (this.codigo != null && !this.codigo.equals(other.codigo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "persistencia.vo.ExperienciaLaboral[ codigo=" + codigo + " ]";
    }
    
}
