/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author USER
 */
@Entity
@Table(name = "empresa")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Empresa.findAll", query = "SELECT e FROM Empresa e")
    , @NamedQuery(name = "Empresa.findByIdentificacion", query = "SELECT e FROM Empresa e WHERE e.identificacion = :identificacion")
    , @NamedQuery(name = "Empresa.findByNombre", query = "SELECT e FROM Empresa e WHERE e.nombre = :nombre")
    , @NamedQuery(name = "Empresa.findByActividadComercial", query = "SELECT e FROM Empresa e WHERE e.actividadComercial = :actividadComercial")
    , @NamedQuery(name = "Empresa.findByPersonaContacto", query = "SELECT e FROM Empresa e WHERE e.personaContacto = :personaContacto")
    , @NamedQuery(name = "Empresa.findByTelefonoContacto", query = "SELECT e FROM Empresa e WHERE e.telefonoContacto = :telefonoContacto")
    , @NamedQuery(name = "Empresa.findByRese\u00f1a", query = "SELECT e FROM Empresa e WHERE e.rese\u00f1a = :rese\u00f1a")
    , @NamedQuery(name = "Empresa.findByCargosSolicitados", query = "SELECT e FROM Empresa e WHERE e.cargosSolicitados = :cargosSolicitados")
    , @NamedQuery(name = "Empresa.findByTipoContrato", query = "SELECT e FROM Empresa e WHERE e.tipoContrato = :tipoContrato")})
public class Empresa implements Serializable {

    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @Column(name = "identificacion")
    private BigDecimal identificacion;
    @Basic(optional = false)
    @Column(name = "nombre")
    private String nombre;
    @Basic(optional = false)
    @Column(name = "actividad_comercial")
    private String actividadComercial;
    @Basic(optional = false)
    @Column(name = "persona_contacto")
    private String personaContacto;
    @Basic(optional = false)
    @Column(name = "telefono_contacto")
    private BigInteger telefonoContacto;
    @Column(name = "rese\u00f1a")
    private String reseña;
    @Column(name = "cargos_solicitados")
    private String cargosSolicitados;
    @Column(name = "tipo_contrato")
    private String tipoContrato;

    public Empresa() {
    }

    public Empresa(BigDecimal identificacion) {
        this.identificacion = identificacion;
    }

    public Empresa(BigDecimal identificacion, String nombre, String actividadComercial, String personaContacto, BigInteger telefonoContacto) {
        this.identificacion = identificacion;
        this.nombre = nombre;
        this.actividadComercial = actividadComercial;
        this.personaContacto = personaContacto;
        this.telefonoContacto = telefonoContacto;
    }

    public BigDecimal getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(BigDecimal identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getActividadComercial() {
        return actividadComercial;
    }

    public void setActividadComercial(String actividadComercial) {
        this.actividadComercial = actividadComercial;
    }

    public String getPersonaContacto() {
        return personaContacto;
    }

    public void setPersonaContacto(String personaContacto) {
        this.personaContacto = personaContacto;
    }

    public BigInteger getTelefonoContacto() {
        return telefonoContacto;
    }

    public void setTelefonoContacto(BigInteger telefonoContacto) {
        this.telefonoContacto = telefonoContacto;
    }

    public String getReseña() {
        return reseña;
    }

    public void setReseña(String reseña) {
        this.reseña = reseña;
    }

    public String getCargosSolicitados() {
        return cargosSolicitados;
    }

    public void setCargosSolicitados(String cargosSolicitados) {
        this.cargosSolicitados = cargosSolicitados;
    }

    public String getTipoContrato() {
        return tipoContrato;
    }

    public void setTipoContrato(String tipoContrato) {
        this.tipoContrato = tipoContrato;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (identificacion != null ? identificacion.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Empresa)) {
            return false;
        }
        Empresa other = (Empresa) object;
        if ((this.identificacion == null && other.identificacion != null) || (this.identificacion != null && !this.identificacion.equals(other.identificacion))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "persistencia.vo.Empresa[ identificacion=" + identificacion + " ]";
    }
    
}
