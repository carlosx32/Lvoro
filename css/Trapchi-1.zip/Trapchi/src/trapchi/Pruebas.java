/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trapchi;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPTable;
//archivos
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
//import javax.swing.text.Document;
import sun.applet.Main;
/**
 *
 * @author usuario
 */
public class Pruebas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
             Font fuente = new Font();
             fuente.setFamily(FontFamily.COURIER.toString());
             fuente.setStyle(Font.BOLD);
             fuente.setSize(12);
             Font fuente1 = new Font();
             fuente1.setFamily(FontFamily.COURIER.toString());
             fuente1.setStyle(Font.ITALIC);
             fuente1.setSize(10);
             
           String IMAGE = "C:\\Users\\usuario\\Pictures\\perfil.jpg";
           String IMAGEn = "C:\\Users\\usuario\\Pictures\\fondoprueba.png";
      
       try {
                // se crea instancia del documento            
                Document mipdf = new Document();
                // se establece una instancia a un documento pdf
                PdfWriter writer = PdfWriter.getInstance(mipdf, new FileOutputStream("C:\\Hojas de vida\\Mi hoja de vida.pdf"));
                mipdf.open();// se abre el documento
                mipdf.addTitle("Hoja de vida"); // se añade el titulo
                mipdf.addAuthor("L'voro -- Trapchi"); // se añade el autor del documento
                mipdf.addSubject("Hoja de vida"); //se añade el asunto del documento
                mipdf.addKeywords("Estudios"
                        + ""); //Se agregan palabras claves 
                 PdfContentByte canvas = writer.getDirectContentUnder();
        Image image = Image.getInstance(IMAGEn);
        image.setAbsolutePosition(0, 0);
        canvas.addImage(image);
                //primera columna
                PdfPTable table = new PdfPTable(1);
                table.setHorizontalAlignment(Element.ALIGN_LEFT);
                table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
                Paragraph parrafo  = new Paragraph("CRISTIAN ANTONIO ESCORCIA BLANCO \n"
                +"INGENIERO DE SISTEMAS \n",fuente);
                parrafo.setAlignment(Element.ALIGN_LEFT);// se añade el contendio del PDF
                table.addCell(parrafo);
                     
                try {
                   Image perfil = Image.getInstance(IMAGE);
                   perfil.scaleAbsolute(20,20);
                   perfil.setAlignment(Element.ALIGN_LEFT);
                    table.addCell(perfil);                        
               } catch (BadElementException ex) {
                   Logger.getLogger(Pruebas.class.getName()).log(Level.SEVERE, null, ex);
               } catch (IOException ex) {
                   Logger.getLogger(Pruebas.class.getName()).log(Level.SEVERE, null, ex);
               }  
                  Paragraph parrafo1  = new Paragraph("Los estudios son varios :\n"
                       + " Primaria : si \n"
                       + " Secundaria : si \n"
                       + " Universidad :  en progreso \n",fuente1);              
                table.addCell(parrafo1);            
                //segunda columna
                  PdfPTable table2 = new PdfPTable(1);
                table2.setHorizontalAlignment(Element.ALIGN_LEFT);
                table2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
                Paragraph parrafo4  = new Paragraph("La experiencia es minina con respecto a lo laboral \n",fuente);
                parrafo.setAlignment(Element.ALIGN_LEFT);// se añade el contendio del PDF
                table2.addCell(parrafo4);                                   
                  Paragraph parrafo5  = new Paragraph("has",fuente1);    
              
                table2.addCell(parrafo5);
                //union columnas
                  PdfPTable table3 = new PdfPTable(2);
                   table3.setWidthPercentage(100);
                  //Datos del ancho de cada columna.
                 table3.setWidths(new float[] {40, 60});
                table3.setHorizontalAlignment(Element.ALIGN_LEFT);
                table3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
                table3.addCell(table);
                table3.addCell(table2);              
                mipdf.add(table3);  
                mipdf.close(); //se cierra el PDF&
                JOptionPane.showMessageDialog(null,"Documento PDF creado");
            } catch (DocumentException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            } catch (FileNotFoundException ex) {      
            Logger.getLogger(Pruebas.class.getName()).log(Level.SEVERE, null, ex);
            
            
        
//        // TODO code application logic here
//        File archivo = new File("C:\\Hojas de vida\\hojavida.txt");
//        
//        try {
//            if(archivo.createNewFile())
//            {
//                System.out.println("Se creo el archivo");
//            }
//        } catch (IOException ex) {
//            Logger.getLogger(Estudios.class.getName()).log(Level.SEVERE, null, ex);
//            System.out.println("No Se ha creo el archivo");
//        }
//        
//        
//        try {
//			//Escritura
//			java.io.BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("C:\\Hojas de vida\\hojavida.txt"));
//			bufferedWriter.append("Esto es la linea 1");
//			bufferedWriter.flush();
//			bufferedWriter.newLine();
//			bufferedWriter.append("Esto es la linea 2");
//			bufferedWriter.flush();
// 
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

    }
    /* metodo que hace uso de la clase itext para manipular archivos PDF*/
            
    
    }
    
}
    

