
import java.math.BigDecimal;
import java.math.BigInteger;
import javax.swing.JOptionPane;
import persistencia.dao.EmpresaJpaController;
import persistencia.dao.UsuarioJpaController;
import persistencia.vo.Empresa;
import persistencia.vo.Usuario1;

public class Lanzador {
//    public Lanzador() {
//        Gestor modelo = new Gestor();
//        modelo.iniciar();
//    }
//
//    ;

    public static void main(String[] args) {
//        new Lanzador();
        int op = 1;
        Empresa emp;
        EmpresaJpaController jpe;
        Usuario1 us;
        UsuarioJpaController jpu;
        do {
            op = Integer.parseInt(JOptionPane.showInputDialog("Que desea hacer?\n1) Introduir datos de una empresa\n2) Introducir datos de un cliente\n0) Salir"));
            switch (op) {
                case 1:
                    emp = new Empresa();
                    jpe = new EmpresaJpaController();
                    emp.setNombre(JOptionPane.showInputDialog("Introduzca el nombre de la empresa"));
                    emp.setIdentificacion((BigDecimal.valueOf(Double.valueOf(JOptionPane.showInputDialog("Introduzca la identificacion de la empresa")))));
                    emp.setActividadComercial(JOptionPane.showInputDialog("¿Cual es la actividad comercial de la empresa?"));
                    emp.setPersonaContacto(JOptionPane.showInputDialog("El nombre de la persona de contacto"));
                    emp.setTelefonoContacto(BigInteger.valueOf(Long.valueOf(JOptionPane.showInputDialog("El numero de la persona de contacto"))));
                    emp.setReseña(JOptionPane.showInputDialog("Escriba una corta reseña de la empresa"));
                    emp.setCargosSolicitados(JOptionPane.showInputDialog("¿Cuales son los cargo solicitados?"));
                    emp.setTipoContrato(JOptionPane.showInputDialog("¿Cual es el tipó de contrato a realizar?"));
                    try {
                        jpe.create(emp);
                        JOptionPane.showMessageDialog(null, "Se creo el registro\n" + emp.getNombre() + "\n" + emp.getIdentificacion() + "\n" + emp.getActividadComercial() + "\n" + emp.getReseña() + "\n" + emp.getPersonaContacto() + "\n" + emp.getTelefonoContacto() + "\n" + emp.getCargosSolicitados() + "\n" + emp.getTipoContrato());
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, ex);
                    }
                    break;
                case 2:
                    break;
            }
        } while (op != 0);
    }

}
